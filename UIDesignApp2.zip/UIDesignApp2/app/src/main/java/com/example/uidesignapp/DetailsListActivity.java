package com.example.uidesignapp;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.HashMap;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class DetailsListActivity extends AppCompatActivity {

    private Retrofit retrofit;
    private RetrofitInterface retrofitInterface;
    private String BASE_URL = "http://10.0.0.69:3000";
    private String firstName, lastName, streetName, streetNumber, state, city, zipCode, email, country, pobox, password, profile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details_list);

        // Initialize UI components
        ImageView back = findViewById(R.id.back);
        ImageView search = findViewById(R.id.search_icon);
        TextView title = findViewById(R.id.title);
        title.setText("Company Profile");

        TextView textViewFirstName = findViewById(R.id.txtfname);
        TextView textViewStreetName = findViewById(R.id.txtSName);
        TextView textViewStreetNumber = findViewById(R.id.txtSNumber);
        TextView textViewState = findViewById(R.id.txtState);
        TextView textViewCountry = findViewById(R.id.txtCountry);
        TextView textViewZipcode = findViewById(R.id.txtZipCode);
        TextView textViewCity = findViewById(R.id.txtCity);
        TextView textViewEmail = findViewById(R.id.txtEmail);
        TextView textViewPobox = findViewById(R.id.txtPoBox);
        Button btnModify = findViewById(R.id.btnModify);
        Button btnConfirm = findViewById(R.id.btnConfirm);

        retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        retrofitInterface = retrofit.create(RetrofitInterface.class);

        //get  profile details
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            firstName = extras.getString("firstName");
            lastName = extras.getString("lastName");
            streetName = extras.getString("streetName");
            streetNumber = extras.getString("streetNumber");
            state = extras.getString("state");
            city = extras.getString("city");
            zipCode = extras.getString("zipCode");
            email = extras.getString("email");
            country = extras.getString("country");
            pobox = extras.getString("pobox");
            password = extras.getString("password");
            profile = extras.getString("profile");

            textViewFirstName.setText(firstName);
            textViewStreetName.setText(streetName);
            textViewStreetNumber.setText(streetNumber);
            textViewState.setText(state);
            textViewCountry.setText(country);
            textViewZipcode.setText(zipCode);
            textViewCity.setText(city);
            textViewEmail.setText(email);
            textViewPobox.setText(pobox);
        }
        btnConfirm.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                //pass profile details in string
                HashMap<String, String> map = new HashMap<>();

                map.put("firstName", firstName.toString());
                map.put("lastName", lastName.toString());
                map.put("streetName", streetName.toString());
                map.put("streetNumber", streetNumber.toString());
                map.put("state", state.toString());
                map.put("city", city.toString());
                map.put("zipCode", zipCode.toString());
                map.put("email", email.toString());
                map.put("country", country.toString());
                map.put("pobox", pobox.toString());
                map.put("password", password.toString());
                map.put("profile", profile.toString());

                Call<Void> call = retrofitInterface.executeUserData(map);
                call.enqueue(new Callback<Void>() {
                    @Override
                    public void onResponse(Call<Void> call, Response<Void> response) {
                        if (response.code() == 200) {
                            Toast.makeText(DetailsListActivity.this,
                                    "User Added successfully", Toast.LENGTH_LONG).show();
                        } else if (response.code() == 400) {
                            Toast.makeText(DetailsListActivity.this,
                                    "Already registered", Toast.LENGTH_LONG).show();
                        }

                    }

                    @Override
                    public void onFailure(Call<Void> call, Throwable t) {
                        Toast.makeText(DetailsListActivity.this, t.getMessage(),
                                Toast.LENGTH_LONG).show();
                    }
                });
            }
        });

        //screen toolbar back button functionality
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}