package com.example.uidesignapp;
import java.util.HashMap;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;
    public interface RetrofitInterface {

        @POST("/add")
        Call<Void> executeUserData(@Body HashMap<String, String> map);
}
